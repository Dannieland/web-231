/*
============================================
; Title:  taplin-favorites.js
; Author: Danielle Taplin
; Date:   31 March 2023
; Description: code to add an alert on button click
;===========================================
*/
function favoriteTeam () { //function to call onClick in html
  alert('Cloud9') //what the button will say when alert pops
}

function favoriteBook () { //function to call onClick in html
  alert('Twilight') //what the button will say when alert pops
}

function favoriteAuthor () { //function to call onClick in html
  alert('Agatha Christie') //what the button will say when alert pops
}

function favoriteLanguage () { //function to call onClick in html
  alert('CSS') //what the button will say when alert pops
}
